﻿@php
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Route as R;

    $routeUrl = function (string $name, string $fallback = '#') {
        return R::has($name) ? route($name) : $fallback;
    };

    $perfilHref = R::has('login') ? route('login') : url('/login');
    $perfilLabel = __('ui.nav.login');
    $logoSources = site_image_sources(theme_asset('logo'), 'logo');
    $activeLocale = $currentLocale ?? request()->route('locale') ?? config('app.locale_prefix_fallback', 'pt');
    $route = request()->route();
    $routeName = $route?->getName();
    $routeParams = collect($route?->parameters() ?? [])->except('locale')->all();
    $flagMap = [
        'pt' => '🇧🇷',
        'en' => '🇺🇸',
        'es' => '🇪🇸',
    ];
    $localeNameMap = [
        'pt' => 'Português',
        'en' => 'English',
        'es' => 'Español',
    ];
    $localeLinks = collect($supportedLocales ?? config('app.supported_locales', []))
        ->map(function ($meta, $prefix) use ($routeName, $routeParams, $activeLocale, $flagMap, $localeNameMap) {
            return [
                'prefix' => $prefix,
                'code' => strtoupper($prefix),
                'name' => $localeNameMap[$prefix] ?? data_get($meta, 'name', strtoupper($prefix)),
                'flag' => $flagMap[$prefix] ?? '🌐',
                'href' => $routeName && R::has($routeName)
                    ? route($routeName, array_merge($routeParams, ['locale' => $prefix]))
                    : url('/'.$prefix),
                'active' => $activeLocale === $prefix,
            ];
        })
        ->values();

    $u = Auth::user();
    if ($u) {
        $perfilLabel = __('ui.nav.profile');

        if (method_exists($u, 'hasRole')) {
            if ($u->hasRole('Admin') && R::has('admin.dashboard')) {
                $perfilHref = route('admin.dashboard');
            } elseif ($u->hasRole('Coordenador') && R::has('coordenador.dashboard')) {
                $perfilHref = route('coordenador.dashboard');
            } elseif ($u->hasRole('Cidadao') && R::has('site.perfil.index')) {
                $perfilHref = route('site.perfil.index');
            } elseif (R::has('dashboard')) {
                $perfilHref = route('dashboard');
            }
        }
    }

    $sections = collect([
        [
            'label' => __('ui.nav.home'),
            'href' => $routeUrl('site.home', url('/')),
            'match' => ['site.home'],
        ],
        [
            'label' => __('ui.nav.explore'),
            'href' => $routeUrl('site.explorar'),
            'match' => ['site.explorar*'],
        ],
        [
            'label' => __('ui.nav.agenda'),
            'href' => $routeUrl('site.agenda'),
            'match' => ['site.agenda', 'eventos.*'],
        ],
        [
            'label' => __('ui.nav.map'),
            'href' => $routeUrl('site.mapa'),
            'match' => ['site.mapa*'],
        ],
        [
            'label' => $perfilLabel,
            'href' => $perfilHref,
            'match' => ['site.perfil*', 'profile*', 'dashboard', 'admin.*', 'coordenador.*', 'login'],
        ],
    ])->filter(fn ($item) => filled($item['href']) && $item['href'] !== '#')->values();

    $navLabel = __('ui.nav.sections');
@endphp

<header class="site-topbar">
    <div class="site-topbar-inner">
        <a href="{{ $routeUrl('site.home', url('/')) }}" class="site-brand">
            <x-picture
                :jpg="$logoSources['jpg'] ?? theme_asset('logo')"
                :webp="$logoSources['webp'] ?? null"
                alt="VisitAltamira"
                class="site-brand-logo"
                sizes="180px"
                :width="$logoSources['width'] ?? null"
                :height="$logoSources['height'] ?? null"
                priority
            />
        </a>

        <nav class="site-topbar-nav" aria-label="{{ $navLabel }}">
            @foreach($sections as $item)
                @php $active = request()->routeIs($item['match']); @endphp
                <a href="{{ $item['href'] }}"
                   class="{{ $active ? 'site-chip site-chip-active' : 'site-chip' }}"
                   @if($active) aria-current="page" @endif>
                    {{ $item['label'] }}
                </a>
            @endforeach
        </nav>

        @if($localeLinks->isNotEmpty())
            <div class="site-topbar-locale" aria-label="{{ __('ui.locale.label') }}">
                @foreach($localeLinks as $localeItem)
                    <a href="{{ $localeItem['href'] }}"
                       class="{{ $localeItem['active'] ? 'site-locale-chip is-active' : 'site-locale-chip' }}"
                       hreflang="{{ strtolower($localeItem['prefix']) }}"
                       lang="{{ strtolower($localeItem['prefix']) }}"
                       title="{{ $localeItem['name'] }}"
                       aria-label="{{ $localeItem['name'] }}">
                        <span class="site-locale-flag" aria-hidden="true">{{ $localeItem['flag'] }}</span>
                        <span class="site-locale-code">{{ $localeItem['code'] }}</span>
                    </a>
                @endforeach
            </div>
        @endif
    </div>
</header>
