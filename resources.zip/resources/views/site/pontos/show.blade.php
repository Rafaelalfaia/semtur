@extends('site.layouts.app')

@php
    use Illuminate\Support\Facades\Route;
    use Illuminate\Support\Facades\Storage;

    $nome = $ponto->nome ?? 'Ponto turístico';
    $cidade = $ponto->cidade ?? 'Altamira';
    $descricao = $ponto->descricao ?? null;
    $categorias = collect($ponto->categorias ?? []);
    $categoriaPrincipal = $categorias->first();
    $capaUrl = $ponto->capa_url
        ?? $ponto->foto_capa_url
        ?? (optional(collect($ponto->midias ?? [])->firstWhere('tipo', 'image'))->path ? Storage::url(collect($ponto->midias ?? [])->firstWhere('tipo', 'image')->path) : null)
        ?? theme_asset('hero_image');
    $pontoCanonical = Route::has('site.ponto')
        ? route('site.ponto', $ponto->slug ?? $ponto->id)
        : url()->current();
    $pontoTitle = $nome.' em Altamira';
    $pontoDescription = \Illuminate\Support\Str::limit(strip_tags($descricao ?: 'Conheça este ponto turístico em Altamira.'), 160);
    $lat = $ponto->lat ?? $ponto->latitude ?? null;
    $lng = $ponto->lng ?? $ponto->longitude ?? null;
    $pontoSchema = [
        [
            '@type' => 'BreadcrumbList',
            '@id' => $pontoCanonical.'#breadcrumbs',
            'itemListElement' => array_values(array_filter([
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Início',
                    'item' => Route::has('site.home') ? route('site.home') : url('/'),
                ],
                Route::has('site.explorar') ? [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Explorar',
                    'item' => route('site.explorar'),
                ] : null,
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $nome,
                    'item' => $pontoCanonical,
                ],
            ])),
        ],
        array_filter([
            '@type' => 'TouristAttraction',
            '@id' => $pontoCanonical.'#place',
            'name' => $nome,
            'description' => $pontoDescription,
            'url' => $pontoCanonical,
            'image' => [$capaUrl],
            'touristType' => $categorias->pluck('nome')->filter()->values()->all(),
            'containedInPlace' => [
                '@type' => 'City',
                'name' => $cidade,
            ],
            'address' => array_filter([
                '@type' => 'PostalAddress',
                'streetAddress' => $ponto->endereco ?? null,
                'addressLocality' => $cidade,
                'addressRegion' => 'PA',
                'addressCountry' => 'BR',
            ], fn ($value) => $value !== null),
            'geo' => (is_numeric($lat) && is_numeric($lng)) ? [
                '@type' => 'GeoCoordinates',
                'latitude' => (float) $lat,
                'longitude' => (float) $lng,
            ] : null,
        ], fn ($value) => $value !== null),
    ];
@endphp

@section('title', $pontoTitle)
@section('meta.description', $pontoDescription)
@section('meta.image', $capaUrl)
@section('meta.canonical', $pontoCanonical)
@section('meta.type', 'article')

@push('structured-data')
<script type="application/ld+json">@json(['@context' => 'https://schema.org', '@graph' => $pontoSchema], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)</script>
@endpush

@section('site.content')
@php
    $mapsUrl = $ponto->maps_url ?: ((is_numeric($lat) && is_numeric($lng)) ? 'https://www.google.com/maps?q='.(float) $lat.','.(float) $lng : null);
    $mapHref = Route::has('site.mapa')
        ? route('site.mapa', array_filter([
            'focus' => 'ponto:'.($ponto->slug ?: $ponto->id),
            'lat' => is_numeric($lat) ? (float) $lat : null,
            'lng' => is_numeric($lng) ? (float) $lng : null,
            'open' => 1,
            'categoria' => $categoriaPrincipal?->slug,
        ], fn($value) => !is_null($value) && $value !== ''))
        : '#';

    $explorarHref = Route::has('site.explorar')
        ? route('site.explorar', array_filter([
            'categoria' => $categoriaPrincipal?->slug,
        ]))
        : '#';

    $galeria = collect($ponto->midias ?? [])
        ->filter(fn($midia) => ($midia->tipo ?? null) === 'image')
        ->sortBy('ordem')
        ->map(function ($midia) use ($nome) {
            $src = $midia->url ?? (!empty($midia->path) ? Storage::url($midia->path) : null);
            return [
                'src' => site_image_url($src, 'gallery'),
                'alt' => $midia->alt ?: 'Foto de '.$nome,
            ];
        })
        ->filter(fn ($item) => filled($item['src']))
        ->values();

    $videos = collect($ponto->midias ?? [])
        ->filter(fn($midia) => in_array($midia->tipo ?? null, ['video', 'video_file', 'video_link'], true))
        ->values();

    $empresas = collect($empresasRelacionadas ?? []);
    $relatedCompanies = $empresas->map(fn($item) => [
        'title' => $item->nome ?? 'Empresa',
        'subtitle' => $item->cidade ?? 'Altamira',
        'summary' => \Illuminate\Support\Str::limit(strip_tags($item->descricao ?? ''), 72),
        'image' => $item->perfil_url ?? $item->capa_url ?? null,
        'href' => Route::has('site.empresa') ? route('site.empresa', $item->slug ?? $item->id) : '#',
    ]);

    $localizacao = collect([
        ['label' => 'Cidade', 'value' => $cidade],
        ['label' => 'Endereço', 'value' => $ponto->endereco ?? null],
        ['label' => 'Bairro', 'value' => $ponto->bairro ?? null],
        ['label' => 'Categoria', 'value' => $categoriaPrincipal?->nome],
    ])->filter(fn ($item) => filled($item['value']))->values();
@endphp

<div class="site-page site-page-shell site-ponto-page">
    @include('site.partials._page_hero', [
        'backHref' => $explorarHref !== '#' ? $explorarHref : (Route::has('site.home') ? route('site.home') : url('/')),
        'breadcrumbs' => [
            ['label' => 'Início', 'href' => Route::has('site.home') ? route('site.home') : url('/')],
            ['label' => 'Explorar', 'href' => $explorarHref !== '#' ? $explorarHref : null],
            ['label' => $nome],
        ],
        'badge' => 'Ponto turístico',
        'title' => $nome,
        'subtitle' => null,
        'meta' => [
            $cidade,
            $categoriaPrincipal?->nome,
        ],
        'primaryActionLabel' => 'Abrir no mapa',
        'primaryActionHref' => $mapHref,
        'secondaryActionLabel' => $mapsUrl ? 'Abrir rota' : (Route::has('site.explorar') ? 'Explorar mais' : null),
        'secondaryActionHref' => $mapsUrl ?: (Route::has('site.explorar') ? $explorarHref : null),
        'image' => $capaUrl,
        'imageAlt' => 'Capa de '.$nome,
    ])

    <section class="site-section">
        <div class="site-detail-grid">
            <article class="site-surface site-detail-main">
                <x-section-head eyebrow="Sobre" title="Conheça este ponto" subtitle="Informações públicas, acesso e contexto do local." />
                <div class="site-detail-copy site-prose">
                    {!! $descricao ?: '<p>Este ponto ainda não tem uma descrição editorial publicada.</p>' !!}
                </div>

                @if($categorias->isNotEmpty())
                    <div class="site-detail-chip-row">
                        @foreach($categorias as $categoria)
                            <a href="{{ Route::has('site.explorar') ? route('site.explorar', ['categoria' => $categoria->slug]) : '#' }}" class="site-filter-chip">
                                {{ $categoria->nome }}
                            </a>
                        @endforeach
                    </div>
                @endif
            </article>

            <aside class="site-detail-aside">
                <section class="site-surface-soft site-content-block">
                    @if($localizacao->isEmpty())
                        <div class="site-empty-state">
                            <p class="site-empty-state-copy">Os dados de localização ainda não foram publicados para este ponto.</p>
                        </div>
                    @else
                        <div class="site-location-card-list">
                            @foreach($localizacao as $item)
                                <div class="site-location-card">
                                    <span class="site-location-card-label">{{ $item['label'] }}</span>
                                    <strong class="site-location-card-value">{{ $item['value'] }}</strong>
                                </div>
                            @endforeach
                        </div>
                    @endif

                    <div class="site-inline-actions">
                        <a href="{{ $mapHref }}" class="site-button-primary">Abrir no mapa</a>
                        @if($mapsUrl)
                            <a href="{{ $mapsUrl }}" target="_blank" rel="noopener noreferrer" class="site-button-secondary">Abrir rota</a>
                        @endif
                        @if($explorarHref !== '#')
                            <a href="{{ $explorarHref }}" class="site-button-secondary">{{ __('ui.common.back_to_explore') }}</a>
                        @endif
                    </div>
                </section>
            </aside>
        </div>
    </section>

    @if($galeria->isNotEmpty())
        <section class="site-section" x-data="{
            canPrev: false,
            canNext: true,
            open: false,
            index: 0,
            images: @js($galeria),
            update() {
                const el = this.$refs.viewport;
                if (!el) return;
                this.canPrev = el.scrollLeft > 12;
                this.canNext = (el.scrollWidth - el.clientWidth - el.scrollLeft) > 12;
            },
            move(direction) {
                const el = this.$refs.viewport;
                if (!el) return;
                const step = Math.max(el.clientWidth * 0.76, 240);
                el.scrollBy({ left: step * direction, behavior: 'smooth' });
                window.setTimeout(() => this.update(), 220);
            },
            show(i) { this.index = i; this.open = true; document.body.style.overflow = 'hidden'; },
            close() { this.open = false; document.body.style.overflow = ''; },
            next() { this.index = (this.index + 1) % this.images.length; },
            prev() { this.index = (this.index - 1 + this.images.length) % this.images.length; }
        }" x-init="$nextTick(() => update())">
            <x-section-head eyebrow="Imagens" title="Galeria" subtitle="Imagens públicas deste ponto turístico." />

            <div class="site-home-carousel-shell site-detail-gallery-shell">
                <div class="site-home-carousel-controls" aria-hidden="true">
                    <button type="button" class="site-home-carousel-control" @click="move(-1)" :disabled="!canPrev" :aria-disabled="!canPrev">&larr;</button>
                    <button type="button" class="site-home-carousel-control" @click="move(1)" :disabled="!canNext" :aria-disabled="!canNext">&rarr;</button>
                </div>

                <div class="site-home-carousel-track site-detail-gallery-track" x-ref="viewport" @scroll.debounce.50ms="update()" x-on:resize.window.debounce.120ms="update()">
                @foreach($galeria as $index => $foto)
                        <div class="site-home-carousel-slide site-detail-gallery-slide">
                            <button type="button" class="site-detail-gallery-card" @click="show({{ $index }})">
                                <img src="{{ $foto['src'] }}" alt="{{ $foto['alt'] }}" loading="lazy" decoding="async" class="site-detail-gallery-image">
                            </button>
                        </div>
                @endforeach
                </div>
            </div>

            <div x-show="open" x-cloak class="site-lightbox" @click.self="close()" x-transition.opacity>
                <div class="site-lightbox-frame site-jogos-lightbox-frame">
                    <button type="button" class="site-lightbox-close" @click="close()" aria-label="Fechar galeria">&times;</button>
                    <button type="button" class="site-lightbox-arrow is-prev" @click.stop="prev()" aria-label="Foto anterior">&#8249;</button>
                    <img :src="images[index]?.src" :alt="images[index]?.alt || ''" class="site-lightbox-image">
                    <button type="button" class="site-lightbox-arrow is-next" @click.stop="next()" aria-label="Próxima foto">&#8250;</button>
                </div>
            </div>
        </section>
    @endif

    @if($videos->isNotEmpty())
        <section class="site-section">
            <x-section-head eyebrow="Vídeos" title="Conteúdos audiovisuais" subtitle="Materiais públicos que ajudam a sentir melhor o lugar antes da visita." />
            <div class="site-card-list-grid">
                @foreach($videos as $video)
                    <div class="site-card">
                        <div class="site-card-list-body">
                            <span class="site-badge">Vídeo</span>
                            <h3 class="site-card-list-title">{{ $video->titulo ?? 'Vídeo do ponto' }}</h3>
                            <p class="site-card-list-summary">{{ \Illuminate\Support\Str::limit(strip_tags($video->descricao ?? ''), 120) }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </section>
    @endif

    <section class="site-section" x-data="{
        canPrev: false,
        canNext: true,
        update() {
            const el = this.$refs.viewport;
            if (!el) return;
            this.canPrev = el.scrollLeft > 12;
            this.canNext = (el.scrollWidth - el.clientWidth - el.scrollLeft) > 12;
        },
        move(direction) {
            const el = this.$refs.viewport;
            if (!el) return;
            const step = Math.max(el.clientWidth * 0.82, 260);
            el.scrollBy({ left: step * direction, behavior: 'smooth' });
            window.setTimeout(() => this.update(), 220);
        }
    }" x-init="$nextTick(() => update())">
        <x-section-head eyebrow="Conexões" title="Empresas relacionadas" subtitle="Serviços e operações publicadas conectadas a este ponto turístico." />

        @if($relatedCompanies->isEmpty())
            <div class="site-empty-state">
                <p class="site-empty-state-copy">Ainda não há empresas relacionadas publicadas para este ponto.</p>
            </div>
        @else
            <div class="site-home-carousel-shell site-detail-related-shell">
                <div class="site-home-carousel-controls" aria-hidden="true">
                    <button type="button" class="site-home-carousel-control" @click="move(-1)" :disabled="!canPrev" :aria-disabled="!canPrev">&larr;</button>
                    <button type="button" class="site-home-carousel-control" @click="move(1)" :disabled="!canNext" :aria-disabled="!canNext">&rarr;</button>
                </div>

                <div class="site-home-carousel-track site-detail-related-track" x-ref="viewport" @scroll.debounce.50ms="update()" x-on:resize.window.debounce.120ms="update()">
                    @foreach($relatedCompanies as $item)
                        <div class="site-home-carousel-slide site-detail-related-slide">
                            <a href="{{ $item['href'] }}" class="site-detail-related-card">
                                <div class="site-detail-related-media">
                                    @if($item['image'])
                                        <img src="{{ site_image_url($item['image'], 'card') }}" alt="{{ $item['title'] }}" class="site-detail-related-image" loading="lazy" decoding="async">
                                    @else
                                        <div class="site-detail-related-placeholder">Sem imagem</div>
                                    @endif
                                </div>
                                <div class="site-detail-related-copy">
                                    <span class="site-badge">Empresa</span>
                                    <h3 class="site-detail-related-title">{{ $item['title'] }}</h3>
                                    <div class="site-detail-related-meta">{{ $item['subtitle'] }}</div>
                                    <p class="site-detail-related-summary">{{ $item['summary'] }}</p>
                                </div>
                                <span class="site-button-secondary site-detail-related-cta">Ver empresa</span>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </section>
</div>
@endsection

